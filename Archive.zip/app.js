const STORAGE_KEY = 'eenhoorn-rekenen-v2';
const levels = [
  ['Cijfers 1 t/m 5', 'mixed', 1, 5, 'Hoeveel zie je?'],
  ['Plaatjes 1 t/m 5', 'mixed', 1, 5, 'Hoeveel zie je?'],
  ['Handjes & dobbelsteen', 'mixed', 1, 6, 'Welk cijfer past erbij?'],
  ['Tot en met 10', 'mixed', 6, 10, 'Tel slim: zie je groepjes van 5?'],
  ['Tienframe tot 10', 'tenframe', 1, 10, 'Hoeveel fiches zie je in het frame?'],
  ['Dominostenen tot 10', 'domino', 1, 10, 'Hoeveel stippen tel je samen?'],
  ['Telrij tot 10', 'line', 1, 10, 'Welk getal is roze?'],
  ['Erbij tot 10', 'add', 1, 10, 'Los het sommetje op.'],
  ['Eraf tot 10', 'subtract', 1, 10, 'Los het sommetje op.'],
  ['Mix: rekenen tot 10', 'mathmix', 1, 10, 'Jij kunt al echt rekenen!']
];

let db = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{"lastName":"","profiles":{}}');
let currentName = db.lastName || '';
let game = null;
let activeTheme = 'unicorn';

const $ = (id) => document.getElementById(id);
const screens = ['startScreen','modeScreen','mapScreen','gameScreen','resultScreen'];

function setTheme(theme){
  activeTheme = theme === 'dino' ? 'dino' : 'unicorn';
  document.body.dataset.theme = activeTheme;
  const appTitle = $('appTitle');
  if (appTitle) {
    appTitle.textContent = activeTheme === 'dino' ? 'Dino Rekenen' : 'Eenhoorn Rekenen';
  }

  const unicornBtn = $('themeUnicornBtn');
  const dinoBtn = $('themeDinoBtn');
  if (unicornBtn && dinoBtn) {
    const isDino = activeTheme === 'dino';
    unicornBtn.classList.toggle('active', !isDino);
    dinoBtn.classList.toggle('active', isDino);
    unicornBtn.setAttribute('aria-pressed', String(!isDino));
    dinoBtn.setAttribute('aria-pressed', String(isDino));
  }
  return activeTheme;
}

function getProfileKey(name){ return name.trim().toLowerCase(); }

function getProfile(){
  if(!currentName) return { scores: {} };
  const key = getProfileKey(currentName);
  if(!db.profiles[key]) db.profiles[key] = { displayName: currentName, scores: {} };
  return db.profiles[key];
}

function save(){ 
  db.lastName = currentName;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); 
}

function show(id){ screens.forEach(s => $(s).classList.toggle('hidden', s !== id)); }
function starsTotal(){ return Object.values(getProfile().scores).reduce((a,b) => a + b, 0); }
function isUnlocked(index){ return true; }

function init(){ 
  if(!$('switchPlayerBtn')) {
    const btn = document.createElement('button');
    btn.id = 'switchPlayerBtn';
    btn.className = 'text-button';
    btn.innerHTML = '👤 Wissel speler';
    btn.style.marginRight = '15px';
    btn.onclick = () => {
      $('playerName').value = '';
      show('startScreen');
    };
    const resetBtn = $('resetButton');
    if (resetBtn && resetBtn.parentNode) {
      resetBtn.parentNode.insertBefore(btn, resetBtn);
    }
  }

  setTheme('unicorn');
  const profile = getProfile();
  $('playerName').value = profile.displayName || currentName; 
  if(currentName) showModeMenu(); else show('startScreen'); 
}

function showModeMenu(){
  show('modeScreen');
}

function showMap(){ 
  const profile = getProfile();
  const nameToShow = profile.displayName || currentName || 'rekenmaatje';
  $('welcomeText').textContent = `Hoi ${nameToShow}!`; 
  $('starTotal').textContent = starsTotal(); 
  const grid = $('levelGrid'); 
  grid.innerHTML = ''; 

  levels.forEach((level, index) => { 
    const score = profile.scores[index] || 0; 
    const b = document.createElement('button'); 
    b.className='level-card'; 
    b.disabled=false; 
    b.innerHTML = `<span class="level-number">LEVEL ${index+1}</span><h3>${level[0]}</h3><p>20 opdrachten</p><span class="card-stars">⭐ ${score}/20</span>`; 
    b.onclick=()=>startLevel(index); 
    grid.appendChild(b); 
  }); 
  show('mapScreen'); 
}

function pick(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }

function makeQuestion(levelIndex, number, prevAnswer){ 
  const [,type,min,max,instruction] = levels[levelIndex]; 
  let kind=type, answer, a, b; 
  
  if(type==='mixed') {
    const options = max <= 5 ? ['hand','apple','dice'] : ['hand','apple','tenframe','domino'];
    kind = options[number % options.length];
  }
  if(type==='mathmix') kind=number%2?'add':'subtract'; 
  
  // Voorkom dubbele vragen achter elkaar
  do {
    if(kind==='add'){ 
      a=pick(1,Math.min(5,max-1)); 
      b=pick(1,max-a); 
      answer=a+b; 
    } else if(kind==='subtract'){ 
      a=pick(2,max); 
      b=pick(1,a-1); 
      answer=a-b; 
    } else { 
      answer=pick(min,max); 
    }
  } while (answer === prevAnswer && (max - min) > 0);

  // Appels/eenhoorns boven de 5 overzetten naar dubbele handjes
  if(kind==='apple' && answer > 5){
    kind = 'hand';
  }

  const themeRoll = Math.random();
  const neutralEmoji = '🍎';
  const themedEmoji = activeTheme === 'dino' ? '🦖' : '🦄';
  const emoji = themeRoll < 0.5 ? themedEmoji : neutralEmoji;
  return {kind,answer,a,b,instruction,emoji}; 
}

function makeNeighbourSequenceQuestion(){
  const length = pick(4, 5);
  const start = pick(1, 8);
  const missingIndex = pick(0, length - 1);
  const sequence = Array.from({ length }, (_, index) => start + index);
  const answer = sequence[missingIndex];
  sequence[missingIndex] = null;

  return {
    kind: 'neighbourSequence',
    answer,
    sequence,
    instruction: 'Vul het ontbrekende getal in.',
    hint: 'Kijk goed naar de volgorde van de getallen.'
  };
}

function makeNeighbourChoiceQuestion(){
  const target = pick(2, 9);
  const mode = Math.random() > 0.5 ? 'large' : 'small';
  const answer = mode === 'large' ? target + 1 : target - 1;

  return {
    kind: 'neighbourChoice',
    answer,
    target,
    mode,
    instruction: mode === 'large' ? 'Wat is de grote buur van dit getal?' : 'Wat is de kleine buur van dit getal?',
    hint: 'Denk aan het getal dat net eerder of later komt.'
  };
}

function startLevel(index){ 
  game = { kind: 'classic', level:index, current:0, correct:0, questions: [], isSubmitting:false};
  const questions = [];
  let prevAns = null;
  for(let i=0; i<20; i++){
    const q = makeQuestion(index, i, prevAns);
    questions.push(q);
    prevAns = q.answer;
  }
  game.questions = questions;
  show('gameScreen'); 
  renderQuestion(); 
}

function startNeighbourSequence(){
  const questions = [];
  for(let i=0; i<10; i++){
    questions.push(makeNeighbourSequenceQuestion());
  }
  game = { kind: 'neighbourSequence', current:0, correct:0, questions, isSubmitting:false };
  show('gameScreen');
  renderQuestion();
}

function startNeighbourChoice(){
  const questions = [];
  for(let i=0; i<10; i++){
    questions.push(makeNeighbourChoiceQuestion());
  }
  game = { kind: 'neighbourChoice', current:0, correct:0, questions, isSubmitting:false };
  show('gameScreen');
  renderQuestion();
}

function renderVisual(q){ 
  const v=$('visual'); 
  v.innerHTML=''; 
  const item = q.emoji || '🍎';
  
  if(q.kind === 'neighbourSequence'){
    const tiles = q.sequence.map((value) => {
      const isMissing = value === null;
      return `<div class="sequence-box ${isMissing ? 'missing' : ''}">${isMissing ? '…' : value}</div>`;
    }).join('');
    v.innerHTML = `<div class="sequence-row">${tiles}</div>`;
    return;
  }

  if(q.kind === 'neighbourChoice'){
    const arrow = q.mode === 'large' ? '→' : '←';
    const answerBox = '<div class="sequence-box answer-slot">?</div>';
    const targetBox = `<div class="sequence-box target">${q.target}</div>`;
    v.innerHTML = `
      <div class="sequence-row neighbour-row">
        ${q.mode === 'large' ? `${targetBox}<div class="arrow-badge">${arrow}</div>${answerBox}` : `${answerBox}<div class="arrow-badge">${arrow}</div>${targetBox}`}
      </div>
    `;
    return;
  }

  if(q.kind==='hand'){
    if(q.answer === 4){
      v.innerHTML = '<div style="display:flex; gap:6px;">' + '<span class="apple">😊</span>'.repeat(4) + '</div>';
    } else if(q.answer === 9){
      v.innerHTML = `<span class="hand" role="img" aria-label="9 vingers">🖐️</span><div style="display:flex; gap:6px; margin-left:12px;">${'<span class="apple">😊</span>'.repeat(4)}</div>`;
    } else {
      const singleHand = ['','☝️','✌️','🤟','','🖐️'];
      if(q.answer <= 5) {
        v.innerHTML = `<span class="hand" role="img" aria-label="${q.answer} vingers">${singleHand[q.answer]}</span>`;
      } else {
        const remainder = q.answer - 5;
        v.innerHTML = `<span class="hand" role="img" aria-label="${q.answer} vingers">🖐️${singleHand[remainder]}</span>`;
      }
    }
  }
  else if(q.kind==='apple'){
    v.innerHTML = `<div style="display:flex; gap:6px;">${`<span class="apple">${item}</span>`.repeat(q.answer)}</div>`;
  }
  else if(q.kind==='dice'){ 
    const renderDiceDots = (num) => {
      const dotPositions = num===1 ? [4] :
                           num===2 ? [0,8] :
                           num===3 ? [0,4,8] :
                           num===4 ? [0,2,6,8] :
                           num===5 ? [0,2,4,6,8] :
                           [0,2,3,5,6,8];
      return Array.from({length:9}, (_, i) => `<span class="dot ${dotPositions.includes(i) ? '' : 'empty'}"></span>`).join('');
    };
    v.innerHTML = '<div class="dice">' + renderDiceDots(q.answer) + '</div>';
  }
  else if(q.kind==='tenframe'){
    // Visueel Tienframe: 2 rijen van 5 vakjes
    const cells = Array.from({length:10}, (_, i) => {
      const filled = i < q.answer;
      return `<div style="width:42px; height:42px; border:2px solid #6d28d9; border-radius:10px; display:flex; align-items:center; justify-content:center; background:#faf5ff;">
        ${filled ? '<span style="width:28px; height:28px; border-radius:50%; background:#ec4899; box-shadow:inset 0 -3px 0 #be185d;"></span>' : ''}
      </div>`;
    }).join('');
    v.innerHTML = `<div style="display:grid; grid-template-columns:repeat(5, 42px); gap:6px; padding:12px; background:#fff; border:3px solid #6d28d9; border-radius:18px; box-shadow:0 6px 0 #ddd6fe;">${cells}</div>`;
  }
  else if(q.kind==='domino'){
    const left = Math.min(q.answer, 5);
    const right = Math.max(0, q.answer - 5);
    const renderDots = (num) => {
      const d = num===1 ? [4] :
                num===2 ? [0,8] :
                num===3 ? [0,4,8] :
                num===4 ? [0,2,6,8] :
                [0,2,4,6,8];
      return Array.from({length:9}, (_, i) => `<span class="dot ${d.includes(i) ? '' : 'empty'}"></span>`).join('');
    };
    v.innerHTML = `<div style="display:flex; gap:6px; background:#fff; padding:8px; border:2px solid #1f2937; border-radius:10px; box-shadow:none;">
      <div class="dice">${renderDots(left)}</div>
      <div class="dice">${right > 0 ? renderDots(right) : ''}</div>
    </div>`;
  }
  else if(q.kind==='egg'){ 
    v.innerHTML='<div class="egg-box">'+Array.from({length:10},(_,i)=>`<span class="egg ${i<q.answer?'':'empty'}"></span>`).join('')+'</div>'; 
  }
  else if(q.kind==='line'){ 
    v.innerHTML = '<div class="number-line">' + Array.from({length:10}, (_, i) => {
      const number = i + 1;
      const isTarget = number === q.answer;
      return `
        <div class="number-slot ${isTarget ? 'target' : ''}">
          <span class="line-tick" aria-hidden="true"></span>
          <span class="line-value">${number}</span>
        </div>
      `;
    }).join('') + '</div>';
  }
  else { 
    const symbol = q.kind==='add' ? '+' : '−';
    let helperHtml = '';
    
    if (q.kind === 'add') {
      const itemsA = Array.from({length: q.a}, () => `<span class="apple">${item}</span>`).join('');
      const itemsB = Array.from({length: q.b}, () => `<span class="apple">${item}</span>`).join('');
      helperHtml = `<div style="margin-top:12px; display:flex; align-items:center; justify-content:center; gap:10px;">
        <div>${itemsA}</div>
        <strong style="color:var(--purple); font-size:1.8rem;">+</strong>
        <div>${itemsB}</div>
      </div>`;
    } else {
      const itemsRemain = Array.from({length: q.a - q.b}, () => `<span class="apple">${item}</span>`).join('');
      const itemsGone = Array.from({length: q.b}, () => `<span class="apple" style="opacity:0.25; filter:grayscale(1);">${item}</span>`).join('');
      helperHtml = `<div style="margin-top:12px; display:flex; align-items:center; justify-content:center; gap:6px;">
        <div>${itemsRemain}${itemsGone}</div>
      </div>`;
    }
    v.innerHTML = `<div><div class="equation">${q.a} ${symbol} ${q.b} = ?</div>${helperHtml}</div>`;
  } 
}

function renderQuestion(){ 
  const q=game.questions[game.current]; 
  game.isSubmitting = false; 
  $('answerInput').disabled = false;

  if (game.kind === 'neighbourSequence' || game.kind === 'neighbourChoice') {
    const label = game.kind === 'neighbourSequence' ? 'Buurgetallen' : 'Grote en kleine buur';
    $('levelTitle').textContent = label;
    $('progressText').textContent = `${game.current + 1} van ${game.questions.length}`;
    $('progressBar').style.width = `${((game.current + 1) / game.questions.length) * 100}%`;
    $('instruction').textContent = q.instruction;
    $('questionHint').textContent = q.hint;
    renderVisual(q);
    $('answerInput').value='';
    $('feedback').textContent='';
    $('answerInput').focus();
    return;
  }

  $('levelTitle').textContent=`Level ${game.level+1}: ${levels[game.level][0]}`; 
  $('progressText').textContent=`${game.current+1} van 20`; 
  $('progressBar').style.width=`${(game.current/20)*100}%`; 
  $('instruction').textContent=q.instruction; 
  
  const objectName = q.emoji === '🦄' ? 'eenhoorns' : q.emoji === '🦖' ? 'dino\'s' : 'appeltjes';
  $('questionHint').textContent=q.kind==='add'||q.kind==='subtract'?`Je mag de ${objectName} erbij tellen.`:'Kijk goed, je hoeft niet te haasten.'; 
  
  renderVisual(q); 
  $('answerInput').value=''; 
  $('feedback').textContent='';$('answerInput').focus(); 
}

function submitAnswer(e){ 
  e.preventDefault(); 
  if(game.isSubmitting) return; 
  
  const answer=Number($('answerInput').value), q=game.questions[game.current]; 
  if($('answerInput').value==='') return; 
  
  game.isSubmitting = true; 
  $('answerInput').disabled = true;

  const good=answer===q.answer; 
  if(good) game.correct++; 
  $('feedback').textContent=good?'Goed zo! ⭐':'Nog even kijken… Het antwoord is '+q.answer+'.'; 
  $('feedback').className='feedback '+(good?'correct':'incorrect'); 
  
  setTimeout(()=>{ 
    game.current++; 
    const totalQuestions = game.questions.length;
    if(game.current >= totalQuestions) finishLevel(); else renderQuestion(); 
  }, good?750:1500); 
}

function finishLevel(){ 
  if (game.kind === 'neighbourSequence' || game.kind === 'neighbourChoice') {
    $('resultEmoji').textContent = game.correct >= 8 ? '🎉' : '🌈';
    $('resultTitle').textContent = game.correct >= 8 ? 'Goed gedaan!' : 'Je bent er bijna!';
    $('resultText').textContent = `Je had ${game.correct} van de ${game.questions.length} buurgetallen goed.`;
    $('earnedStars').textContent = '⭐'.repeat(Math.min(game.correct, 10)) + (game.correct > 10 ? ' +' + (game.correct - 10) : '');
    show('resultScreen');
    return;
  }

  const profile = getProfile();
  const old=profile.scores[game.level]||0; 
  profile.scores[game.level]=Math.max(old,game.correct); 
  save(); 
  
  const unlocked=game.correct>=14; 
  $('resultEmoji').textContent=unlocked?'🎉':'🌈'; 
  $('resultTitle').textContent=unlocked?'Level gehaald!':'Goed geoefend!';$('resultText').textContent=`Je had ${game.correct} van de 20 opdrachten goed.${unlocked?' Het volgende level is nu vrij!':' Voor het volgende level heb je 14 sterren nodig. Probeer dit level gerust nog eens.'}`; 
  $('earnedStars').textContent='⭐'.repeat(Math.min(game.correct,10))+(game.correct>10?' +'+(game.correct-10):''); 
  show('resultScreen'); 
}

$('startButton').onclick=()=>{ 
  const inputName = $('playerName').value.trim(); 
  currentName = inputName || 'rekenmaatje'; 
  
  const profile = getProfile();
  if(!profile.displayName) profile.displayName = currentName;
  
  save(); 
  showModeMenu(); 
};

$('themeUnicornBtn').onclick = () => setTheme('unicorn');
$('themeDinoBtn').onclick = () => setTheme('dino');

$('level1Button').onclick = () => showMap();
$('level2Button').onclick = () => startNeighbourSequence();
$('level3Button').onclick = () => startNeighbourChoice();

$('answerForm').onsubmit=submitAnswer; 
$('backButton').onclick=() => {
  if (game && (game.kind === 'neighbourSequence' || game.kind === 'neighbourChoice')) {
    showModeMenu();
    return;
  }
  showMap();
};
$('againButton').onclick=() => {
  if (game && (game.kind === 'neighbourSequence' || game.kind === 'neighbourChoice')) {
    showModeMenu();
    return;
  }
  showMap();
};

$('resetButton').onclick=()=>{ 
  const n1 = pick(6, 9);
  const n2 = pick(6, 9);
  const correctMathAnswer = n1 * n2;
  
  const parentAnswer = prompt(`🔒 Ouder-controle\n\nAls je alle opgeslagen gegevens wilt wissen, los dan eerst deze som op:\n\nHoeveel is ${n1} x ${n2}?`);
  
  if(parentAnswer !== null && Number(parentAnswer) === correctMathAnswer) {
    if(confirm('Weet je heel zeker dat je ALLE opgeslagen profielen en voortgang wilt wissen?')){ 
      db = { lastName: '', profiles: {} };
      currentName = '';
      save(); 
      init(); 
      alert('Alle gegevens zijn succesvol gewist.');
    } 
  } else if(parentAnswer !== null) {
    alert('Dat antwoord is helaas niet juist. Er is niets gewist.');
  }
};

init();